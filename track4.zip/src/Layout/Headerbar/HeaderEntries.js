export const navList = [
    {
      id: 1,
      tabText:"Movie",
      nav: '/Movies',
    //   tabColor: "#EE8E54",
    },
    {
      id: 2,
      tabText:"Location",
      nav: "/Location",
    //   tabColor: "#EE8E54",
    },
    {
      id: 3,
      tabText:"category",
      nav: "/Track/Category",
    //   tabColor: "#EE8E54",
    },
    {
      id: 4,
      tabText:"Subcategory",
      nav: "/Track/Subcategory",
    //   tabColor: "#EE8E54",
    // tabColor: NoEncryptionGmailerrorred,
    },
    {
      id: 5,
      tabText:"Crew",
      nav: "/Track/Crew",
    //   tabColor: "#EE8E54",
    },
   
  ];
  export const TrackList=[];