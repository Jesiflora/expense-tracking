import React, { useState, useEffect } from "react";
import { Box, Grid } from "@mui/material";
import CustomTab from "../../components/CustomTab";
import * as MASTER from "./HeaderEntries";
// import TabList from "./HeaderEntries";
import Location from "../../page/Masters/location/Location";
import Category from "../../page/Masters/category/Category";
import Subcategory from "../../page/Masters/SubCategory/SubCategory";
import Crewpage from "../../page/Masters/crew/Crewpage";
import Movies from "../../page/Masters/movie/Movies";
import Expense from "../../page/ExpenseSheet/ExpenseSheet";
const Header = () => {
  const [tabValue, setTabValue] = useState(0);

  const handleChange = (event, newValue) => {
    setTabValue(newValue);
  };

 

  return (
    <Box flex={1}>
      <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
        <Grid item xs={10}>
          <CustomTab
            tabList={MASTER.navList}
            handleChange={handleChange}
            value={tabValue}
            sx={{
              "&.MuiTab-root": {
                "&.Mui-selected": {
                  color: "black",
                },
              },
            }}
          />
        </Grid>
      </Grid>
      {tabValue === 0 && <Movies />}  
      {tabValue === 1 && <Location />}
      {tabValue === 2 && <Category />}
      {tabValue === 3 && <Subcategory />}
      {tabValue === 4 && <Crewpage />}
    </Box>
  );
};

export default Header;
