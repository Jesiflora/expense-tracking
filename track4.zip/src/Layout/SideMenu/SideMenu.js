// import React from 'react';
// import { NavLink } from 'react-router-dom';

// export const SideMenu = () => {
//   return (
//     <>
//     <li>Masters</li>
//     <NavLink to="/Expense">
//     <li>Expense Sheet</li>
//     </NavLink>
//     <li>Report</li>
//     </>
//   )
// }
