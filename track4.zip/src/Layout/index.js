// import React from 'react';
// import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
// import Crewpage from '../page/Masters/crew/Crewpage';
// import Expense from '../page/ExpenseSheet/ExpenseSheet';


// function App() {
//   return (
//     <Router>
//       <Switch>
//         <Route exact path="/" component={Crewpage} />
//         <Route path="/about" component={Expense} />
//       </Switch>
//     </Router>
//   );
// }

// export default App;
import React from 'react';
// import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

import Movies from '../page/Masters/movie/Movies';
import Location from '../page/Masters/location/Location';
import Category from '../page/Masters/category/Category';
import Subcategory from '../page/Masters/SubCategory/SubCategory';
import Crewpage from '../page/Masters/crew/Crewpage';
import Expense from '../page/ExpenseSheet/ExpenseSheet';


/**
 *
 * @returns
 */
function Layout() {

  return (
    // <Router>
    <Routes>
      <Route path="/" index element={<Movies/>}/>
      <Route path="Location" element={<Location />}>
        <Route path="Category" element={<Category/>} />
        <Route path="SubCategory" element={<Subcategory />} />
        <Route path="crewpage" element={<Crewpage />} />
        <Route path="Expense" element={<Expense />} />
        
      </Route>
    </Routes>
    // </Router>
  );
}
export default Layout;