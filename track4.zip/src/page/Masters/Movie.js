
// import * as React from 'react';
// import Grid from '@mui/material/Grid';
// import Paper from '@mui/material/Paper';
// import  { useState } from 'react';
// import Radio from '@mui/material/Radio';
// import RadioGroup from '@mui/material/RadioGroup';
// import FormControlLabel from '@mui/material/FormControlLabel';
// import FormControl from '@mui/material/FormControl';
// import FormLabel from '@mui/material/FormLabel';
// import { Box, Container, Typography } from "@mui/material";
// import { styled } from '@mui/material/styles';


// const Item = styled(Paper)(({ theme }) => ({
//   backgroundColor: "blue",
//   ...theme.typography.body2,
 
  
//   color: theme.palette.secondary,
// }));

// const Movies = () => {
//   const [selectedMovie, setSelectedMovie] = useState('');
//   const [selectedLocation, setSelectedLocation] = useState('');
//   const [selectedCategory, setSelectedCategory] = useState('');
//   const [selectedSubCategory, setSelectedSubCategory] = useState('');
 
//   const handleMovie = (event) => {
//     setSelectedMovie(event.target.value);
//   };

//   const handleLocation = (event) => {
//     setSelectedLocation(event.target.value);
//   };

//   const handleCategory = (event) => {
//     setSelectedCategory(event.target.value);
//   }
//   const handleSubCategory = (event) => {
//     setSelectedSubCategory(event.target.value);
//   return (

//     <>
//     <div >
//      <Grid container spacing={2} >
//        <Container>
//          <Box display="flex" justifyContent="space-between" mt={4}>
//            <Box
//              width="95%"
//              height={200}
//              bgcolor="primary.main"
//              color="primary.contrastText"
//              p={2}
//              borderRadius={8}
//              boxShadow={3}
//            >
  
//       <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 3, md: 3 }}>
//         <Grid item xs={4}>
//           <Item><div>
//        <label>Movie Name</label>
//         <select value={selectedMovie} onChange={handleMovie}>
//         <option value="option1">Option 1</option>
//         <option value="option2">Option 2</option>
//         <option value="option3">Option 3</option>
//         <option value="option4">Option 4</option>
//         </select>
//  </div></Item>
//         </Grid>
//         <Grid item xs={4}>
//           <Item><label>Location</label>
//         <select value={selectedLocation} onChange={handleLocation}>
//         <option value="option1">Option 1</option>
//         <option value="option2">Option 2</option>
//         <option value="option3">Option 3</option>
//         <option value="option4">Option 4</option>
//         </select></Item>
//         </Grid>
//         <Grid item xs={4}>
//           <Item><div>
//         <label>category</label>
//         <select value={selectedCategory} onChange={handleCategory}>
//         <option value="option1">Option 1</option>
//         <option value="option2">Option 2</option>
//         <option value="option3">Option 3</option>
//         <option value="option4">Option 4</option>
//         </select>
//       </div></Item>
//         </Grid>
//         <Grid item xs={4}>
//           <Item><div>
//         <label>Subcategory</label>
//         <select value={selectedSubCategory} onChange={handleSubCategory}>
//         <option value="option1">Option 1</option>
//         <option value="option2">Option 2</option>
//         <option value="option3">Option 3</option>
//         <option value="option4">Option 4</option>
//         </select>
//       </div></Item>
//         </Grid>
//         <Grid item xs={4}>
//           <Item><div>
//  <FormControl>
//       <FormLabel id="demo-row-radio-buttons-group-label">Gender</FormLabel>
//       <RadioGroup
//         row
//         aria-labelledby="demo-row-radio-buttons-group-label"
//         name="row-radio-buttons-group"
//       >
//         <FormControlLabel value="female" control={<Radio />} label="Female" />
//         <FormControlLabel value="male" control={<Radio />} label="Male" />
//         <FormControlLabel value="other" control={<Radio />} label="Other" />
       
//       </RadioGroup>
//     </FormControl>
//  </div>
//    </Item>
//         </Grid>
//         <Grid item xs={4}>
//           <Item></Item>
//         </Grid>
//         <Grid item xs={4}>
//           <Item>7</Item>
//         </Grid>
//         <Grid item xs={4}>
//           <Item>8</Item>
//         </Grid>
//         <Grid item xs={4}>
//           <Item>9</Item>
//         </Grid>
//       </Grid>
//       </Box>
  
//   </Box>
// </Container>
// </Grid>

// <Grid container>
// <Container>
//   <Box
//     width="95%"
//     height={200}
//     bgcolor="secondary.main"
//     color="secondary.contrastText"
//     p={2}
//     borderRadius={8}
//     boxShadow={3}
//     mt={4}
//   >
//     <Table />
//   </Box>
// </Container>
// </Grid>
// </div>
// </>
    
//   )
// }

// export default Movies;