import { Box, Container, Pagination } from '@mui/material';
import React from 'react';
import { Buttons } from '../../../components/Buttons ';
import SearchBar from '../../../components/SearchAppBar';
import './Category.css';

class CategoryTable extends React.Component {
  state = {
    page: 0,
    rowsPerPage: 5,
    searchQuery: '',
  };

  handleChangePage = (event, newPage) => {
    this.setState({ page: newPage });
  };

  handleChangeRowsPerPage = event => {
    this.setState({ rowsPerPage: parseInt(event.target.value, 10), page: 0 });
  };

  handleSearchChange = event => {
    this.setState({ searchQuery: event.target.value });
  };

  render() {
    const headings = ['S.No', 'Movie Name', 'Category', 'Created Date', 'Actions'];
    
    const rows = [
      ['1', 'AAA', 'Active', '01/01/2024', <Buttons />],
      ['2', 'BBB', 'Inactive', '02/02/2024', <Buttons />],
      ['3', 'CCC', 'Active', '06/03/2024', <Buttons />],
      ['4', 'DDD', 'Inactive', '05/04/2024', <Buttons />],
      ['5', 'EEE', 'Active', '22/06/2024', <Buttons/>]
    ];

    const { page, rowsPerPage, searchQuery } = this.state;

    const filteredRows = rows.filter(row =>
      row.some(cell => cell.toLowerCase().includes(searchQuery.toLowerCase()))
    );

    return (
        <Container>
          <Box
            width="95%"
            height={230}
            bgcolor="white"
            color="black"
            p={2}
            borderRadius={3}
            boxShadow={3}
            mt={4}
          >
      <div className="table-container">
        <h2>Movies</h2>
        <div className="SearchBar">
        <SearchBar/>
        </div>
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                {headings.map((heading, index) => (
                  <th key={index}>{heading}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, rowIndex) => (
                <tr key={rowIndex}>
                  {row.map((data, dataIndex) => (
                    <td key={dataIndex}>{data}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        </div>
        <div className="pagination-container">
          <span className="info" >Page {page * rowsPerPage + 1},  Out of {filteredRows.length}</span>
          <Pagination
            count={Math.ceil(filteredRows.length / rowsPerPage)}
            page={page}
            onChange={this.handleChangePage}
            shape="rounded"
            className="pagination"
          />
        
        </div>
      {/* </div> */}
      </Box>
      </Container>
    );
  }
}

export default CategoryTable;