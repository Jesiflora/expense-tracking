import { Box, Container, Grid } from "@mui/material";
import { styled } from '@mui/material/styles';
import React, { useState } from 'react';
import './Location.css';
import LocationTable from './LocationTable';

const Item = styled('div')(({ theme }) => ({
    ...theme.typography.body2,
    color: theme.palette.secondary,
}));

const Location = () => {
    const [selectedValue, setSelectedValue] = useState('');
    const [categoryValue, setCategoryValue] = useState('');
    const [countryCode, setCountryCode] = useState('');
    const [phoneNumber, setPhoneNumber] = useState('');
    const [errors, setErrors] = useState({});

    const handleChange = (event) => {
        setSelectedValue(event.target.value);
    };

    const handleCountryCodeChange = (event) => {
        setCountryCode(event.target.value);
    };

    const handlePhoneNumberChange = (event) => {
        setPhoneNumber(event.target.value);
    };

    const handleSubmit = () => {
        const errors = {};

        if (!countryCode || !phoneNumber.trim()) {
            errors.phoneNumber = 'Please enter a valid phone number';
        }

        setErrors(errors);

        if (Object.keys(errors).length === 0) {
            console.log('Form submitted successfully');
            // Add logic for form submission
        }
    };

    const countryCodes = [
        { code: '+1' },
        { code: '+91' },
        { code: '+44' },
        // Add more country codes here
    ];

  return (
    <div >
      <Grid container item md={12} lg={12} sm={12} xs={12} >
        <Container>
          <Box display="flex" justifyContent="space-between" mt={4}>
            <Box
              width="100%"
              
              bgcolor="white"
              color="black"
              p={3}
              borderRadius={3}
              boxShadow={3}
            >
            
    
    <Grid container md={12} lg={12} sm={12} xs={12} rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
        <Grid item xs={12} md={4} lg={4} sm={6}>
          <Item>
            <div className='firtdiv'>
                <label>Movie Name</label>
     
      <select value={selectedValue} onChange={handleChange} className='Moviename'>
      <option value="" disabled>Select Movie</option>
      <option value="option1">Option 1</option>
      <option value="option2">Option 2</option>
      <option value="option3">Option 3</option>
      <option value="option4">Option 4</option>
    </select>
  {/* </Item>
</Grid> */}
    </div>
    </Item>
        </Grid>
        <Grid item xs={12} md={3} lg={3} sm={6}>
          <Item><div secdiv>
        <label>Location</label>
        <input
        type="text"
        value={categoryValue}
        onChange={(e)=>(setCategoryValue(e.target.value))}
        // variant="outlined"
        placeholder='Enter Location'
        className='category'></input>
    </div></Item>
        </Grid>
        <Grid item xs={12} md={1} lg={1} sm={6}>
          <Item>
            <div>
            <button type="submit" className='adding'>+</button>
            </div>
          </Item>
        </Grid>
        <Grid item xs={12} md={4} lg={4} sm={10} >
          <Item>
          <div className="number-text-field">
                      <label className="label">Phone Number</label>
                      <div className="input-container">
                        <select
                          value={countryCode}
                          onChange={handleCountryCodeChange}
                          className="country-code"
                        >
                          <option value=""></option>
                          {countryCodes.map((country) => (
                            <option key={country.code} value={country.code}>
                              {country.code}
                            </option>
                          ))}
                        </select>
                        <input
                          className="phone-number"
                          type="text"
                          value={phoneNumber}
                          onChange={handlePhoneNumberChange}
                          placeholder="Enter Phone Number"
                        />
                      </div>
                    </div>
          </Item>
        </Grid>
        <Grid item xs={12} md={9} lg={9} sm={6}>
          <Item>
           
          </Item>
        </Grid>
        <Grid item xs={12} md={1.5} lg={1.5} sm={6}>
          <Item>
           <button className='submit'>submit</button>
          </Item>
        </Grid>
        <Grid item xs={12} md={1.5} lg={1.5} sm={6}>
          <Item>
           <button className='cancel'>cancel</button>
          </Item>
        </Grid>
        
      </Grid>
              
            </Box>
          </Box>
        </Container>
      </Grid>

      <Grid container>
        <Container>
          <Box
          
            height="83%"
            bgcolor="white.main"
            color="secondary.contrastText"
            p={2}
            borderRadius={8}
            boxShadow={3}
            mt={4}
          >
            <LocationTable/>
          </Box>
        </Container>
      </Grid>
    </div>
  );
};

export default Location;