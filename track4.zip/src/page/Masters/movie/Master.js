import { Grid } from "@mui/material";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import Tabs from "@mui/material/Tabs";
import PropTypes from "prop-types";
import * as React from "react";

import Subcategory from "../SubCategory/SubCategory";
import Category from "../category/Category";
import Crewpage from "../crew/Crewpage";
import Location from "../location/Location";
import "./Master.css";
import Movies from "./Movies";

function CustomTabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      style={{ height: "100%" }} // Set height to 100%
      {...other}
    >
      {value === index && <div style={{ height: "100%" }}>{children}</div>}
    </div>
  );
}

CustomTabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(name) {
  return {
    id: `simple-tab-${name}`,
    "aria-controls": `simple-tabpanel-${name}`,
  };
}

const Masters = () => {
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <div className="master-main-page">
      <Box
        sx={{
          width: " 100%",
          minHeight: "100vh",
          maxHeight: "100%",
          background: `var(--page-bg-color)`,
        }}
      >
        <Box sx={{ borderColor: "divider", height: "16%" }}>
          <Grid container md={12} sx={{ height: "55%" }}>
            <Grid
              item
              md={12}
              sx={{
                display: "flex",
                justifyContent: "space-between",
              }}
            >
              <div className="pages-h1">
                <h1>Masters</h1>
              </div>
              <div
                className="d-flex align-items-end"
                style={{ marginBottom: "-46px" }}
              >
                <div className=" user-div d-flex ">
                  <div className="username">Username </div>
                  <div className="user-img-div">
                    
                  </div>
                </div>
              </div>
            </Grid>
          </Grid>
          <Tabs
            value={value}
            onChange={handleChange}
            aria-label="basic tabs example"
            sx={{
              height: "45%",
            }}
          >
            <Tab
              label="Movie"
              {...a11yProps("Movie")}
              sx={{
                marginLeft: "30px",
                marginRight: "50px",
                textTransform: "none",
              }}
            />
            <Tab
              label="Location"
              {...a11yProps("Location")}
              sx={{ marginRight: "50px", textTransform: "none" }}
            />
            <Tab
              label="Category"
              {...a11yProps("Category")}
              sx={{ marginRight: "50px", textTransform: "none" }}
            />

            <Tab
              label="Subcategory"
              {...a11yProps("Subcategory")}
              sx={{ marginRight: "50px", textTransform: "none" }}
            />
            <Tab
              label="Crew"
              {...a11yProps("Crew")}
              sx={{ textTransform: "none" }}
            />
          </Tabs>
        </Box>
        <Box sx={{ width: " 100%", height: "82%", marginTop: "1%" }}>
          <CustomTabPanel value={value} index={0}>
            <Movies/>
          </CustomTabPanel>
          <CustomTabPanel value={value} index={1}>
            <Location />
          </CustomTabPanel>
          <CustomTabPanel value={value} index={2}>
            <Category/>
          </CustomTabPanel>
          <CustomTabPanel value={value} index={3}>
            <Subcategory />
          </CustomTabPanel>
          <CustomTabPanel value={value} index={4}>
            <Crewpage />
          </CustomTabPanel>
        </Box>
      </Box>
    </div>
  );
};

export default Masters;
