import React from 'react';
import { Tabs, Tab, Box } from '@mui/material';
import PropTypes from 'prop-types';
import './ComponentStyles.css';
/**
 *
 * @param {object} props - require props in CustomTab component
 * @returns {React.ReactElement} - returns the CustomTab component
 */
function CustomTab(props) {
  const { tabList, handleChange, value } = props;
  return (
    <Box sx={{ width: '100%', display: 'flex' }}>
      {tabList?.map((item, index) => {
        const key = index;
        return (
          <Tabs
            value={value}
            className="gggg"
            onChange={handleChange}
            TabIndicatorProps={{
              style: {
                backgroundColor: item.tabColor,
                textColor: item.textColor,
              },
            }}
          >
            <Tab
              value={key}
              label={item.tabText}
              className="tabValueIndicator"
              sx={{
                '&.MuiTab-root': {
                  '&.Mui-selected': {
                    color: item.tabColor,
                    fontWeight: 600,
                    fontSize: '16px',
                  },
                },
              }}
            />
          </Tabs>
        );
      })}
    </Box>
  );
}
export default CustomTab;
CustomTab.propTypes = {
  tabList: PropTypes.arrayOf(PropTypes.objectOf).isRequired,
  handleChange: PropTypes.func.isRequired,
  value: PropTypes.number.isRequired,
};
