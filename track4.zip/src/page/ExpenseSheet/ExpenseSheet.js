import EventIcon from '@mui/icons-material/Event';
import { Box, Container, Grid } from '@mui/material';
import Button from '@mui/material/Button';
import InputAdornment from '@mui/material/InputAdornment';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import { styled } from '@mui/material/styles';
import React, { useState } from 'react';
import SearchBar from '../../components/SearchAppBar';
import '../ExpenseSheet/ExpenseTable.css';
import ExpenseTable from './ExpenseTable';

const Item = styled('div')(({ theme }) => ({
    backgroundColor: "white",
    ...theme.typography.body2,
   
    
    color: theme.palette.secondary,
  }));
const Expense = () => {
  const [numberInput, setNumberInput] = useState(''); 
  const [selectedMovie, setSelectedMovie] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSubCategory, setSelectedSubCategory] = useState('');
  const [selectedCrew, setSelectedCrew] = useState('');
  const [numberOutput, setNumberOutput]= useState('');
  const [numberSide, setNumberSide]= useState('');
  const handleMovie = (event) => {
    setSelectedMovie(event.target.value);
  };

  const handleLocation = (event) => {
    setSelectedLocation(event.target.value);
  };

  const handleCategory = (event) => {
    setSelectedCategory(event.target.value);
  }
  const handleSubCategory = (event) => {
    setSelectedSubCategory(event.target.value);
  }
  const handleCrew= (event) => {
    setSelectedCrew(event.target.value);
  }
  
  const handleInputChange = (event) => {
    const inputValue = event.target.value;
    
    // Check if the input is a valid number
    if (!isNaN(inputValue)) {
      // Update the state if the input is valid
      setNumberInput(inputValue);
    }
  };
  const handleOutputChange = (event) => {
    const outputValue = event.target.value;
    
    // Check if the input is a valid number
    if (!isNaN(outputValue)) {
      // Update the state if the input is valid
      setNumberOutput(outputValue);
    }
  };
  const handleSideChange = (event) => {
    const SideValue = event.target.value;
    
    // Check if the input is a valid number
    if (!isNaN(SideValue)) {
      // Update the state if the input is valid
      setNumberSide(SideValue);
    }
  };
  
  return (

<>
<div >
  <h2 style={{ marginLeft: '20px' }}>Expense Sheet</h2>
<Grid container  md={12} lg={12} sm={12} xs={12}>
   <Container>
     <Box display="flex" justifyContent="space-between" mt={4}>
       <Box
         width="100%"
        //  height={200}
         bgcolor="White"
         color="black"
         p={2}
         borderRadius={8}
         boxShadow={3}
       >

  <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 3, md: 3 }}>
    <Grid item md={4} lg={4} sm={6} xs={12}>
      <Item><div>
   <label className='select'>Movie Name</label>
    <select  className="Movie"value={selectedMovie} onChange={handleMovie}>
    <option value="" disabled>Select Movie</option>
  
    <option value="option1">Option 1</option>
    <option value="option2">Option 2</option>
    <option value="option3">Option 3</option>
    <option value="option4">Option 4</option>
    </select>
</div></Item>
    </Grid>
    <Grid item  md={4} lg={4} sm={6}xs={12}>
      <Item><label>Location</label>
    <select className="Movie" value={selectedLocation} onChange={handleLocation}>
    <option value="" disabled>Select Location</option>
  
    <option value="option1">Option 1</option>
    <option value="option2">Option 2</option>
    <option value="option3">Option 3</option>
    <option value="option4">Option 4</option>
    </select></Item>
    </Grid>
    <Grid item md={4} lg={4} sm={6} xs={12}>
      <Item>
        <div className='outline'>
    <label>Date</label>
    
        <TextField
      className='MovieS'
      placeholder="Select Date"
      
      InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <EventIcon />
          </InputAdornment>
           ),
          }}
        />
  </div></Item>
    </Grid>
    <Grid item md={4} lg={4} sm={6} xs={12}>
      <Item><div>
    <label>Crew Name</label>
    <select className="Movie" value={selectedCrew} onChange={handleCrew}>
    <option value="" disabled>Select Crew</option>  
    <option value="option1">Option 1</option>
    <option value="option2">Option 2</option>
    <option value="option3">Option 3</option>
    <option value="option4">Option 4</option>
    </select>
  </div></Item>
    </Grid>
    <Grid item xs={4}>
      <Item>
      <Item><div>
    <label>category</label>
    <select className="Movie" value={selectedCategory} onChange={handleCategory}>
    <option value="" disabled>Select Category</option> 
    <option value="option1">Option 1</option>
    <option value="option2">Option 2</option>
    <option value="option3">Option 3</option>
    <option value="option4">Option 4</option>
    </select>
  </div></Item>
    
     
    
</Item>
    </Grid>
    <Grid item md={4} lg={4} sm={6} xs={12}>
    <Item><div>
    <label>Subcategory</label>
    <select className="Movie" value={selectedSubCategory} onChange={handleSubCategory}>
    <option value="" disabled>Select SubCategory</option>
    <option value="option1">Option 1</option>
    <option value="option2">Option 2</option>
    <option value="option3">Option 3</option>
    <option value="option4">Option 4</option>
    </select>
  </div></Item>
    </Grid>
    <Grid item md={4} lg={4} sm={6} xs={12}>
      <Item> <label>  Number of Persons</label>
      <input  className="Movie"
      type="text"
      value={numberOutput}
      onChange={handleOutputChange}
      placeholder="Enter a number"
    />
      
    </Item>
    </Grid>
    <Grid item md={4} lg={4} sm={6} xs={12}>
      <Item><label>Advance</label>
      <input  className="Movie"
      type="text"
      value={numberSide}
      onChange={handleSideChange}
      placeholder="Enter a number"
    />
    </Item>
    </Grid>
    <Grid item md={4} lg={4} sm={6} xs={12}>
      <Item><label >Beta</label>
      <input  className="Movie"
      type="text"
      value={numberInput}
      onChange={handleInputChange}
      placeholder="Enter a number"
    />
    </Item>
    </Grid>
    <Grid item md={4} lg={4} sm={6} xs={12}>
      <Item></Item>
    </Grid>
    <Grid item xs={4}>
      <Item></Item>
    </Grid>
    
    <Grid item md={4} lg={4} sm={6} xs={12}>
      <Item> <Stack direction="row" spacing={2}>
      <Button variant="contained">Submit</Button>
      <Button variant="contained" disabled> cancel</Button>
      </Stack></Item>
    </Grid>
  </Grid>
  </Box>

</Box>
</Container>
</Grid>

<Grid container md={12} lg={12} sm={12} xs={12}>
<Container>
<Box
width="95%"

bgcolor='#f5f5f5'
color="black"
p={2}
borderRadius={8}
boxShadow={3}
mt={2}
>
<div>
    <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 3, md: 3 }}>
    <Grid item xs={2}>
        <h3>Expense</h3>
        </Grid>
        <Grid item xs={8}>
        </Grid>
        <Grid item xs={2}>
        <SearchBar/>
              </Grid>
        </Grid>
  <ExpenseTable/>
        </div>
</Box>
</Container>
</Grid>

</div>
</>
  )
}

export default Expense;