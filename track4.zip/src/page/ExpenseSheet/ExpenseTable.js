import React from 'react';
import './ExpenseSheet.css';
import {  Pagination } from '@mui/material';
import { Buttons } from '../../components/Buttons ';


class Table extends React.Component {
  state = {
    page: 0,
    rowsPerPage: 5,
    searchQuery: '',
  };

  handleChangePage = (event, newPage) => {
    this.setState({ page: newPage });
  };

  handleChangeRowsPerPage = event => {
    this.setState({ rowsPerPage: parseInt(event.target.value, 10), page: 0 });
  };

  handleSearchChange = event => {
    this.setState({ searchQuery: event.target.value });
  };

  render() {
    const headings = ['S.No', 'Movie Name', 'Location','Category','SubCategory','crew Name','Gender', 'Mobile Number','Nationality','Created Date', 'Actions'];

    const rows = [
      ['1', 'AAA', 'Anna nager','111111','tttt','ggg','ttt' ,'female','01/01/2024','indian',<Buttons/>],
      ['2', 'BBB', 'Velachery','2222222','tttt','ggg', 'kk','male', '02/02/2024', 'indian',<Buttons/>],
     
     
      // Add more rows as needed
    ];

    const { page, rowsPerPage, searchQuery } = this.state;

    const filteredRows = rows.filter(row =>
      row.some(cell => cell.toLowerCase().includes(searchQuery.toLowerCase()))
    );

    const totalRows = filteredRows.length;
    const totalPages = Math.ceil(totalRows / rowsPerPage);

    const renderRows = filteredRows.slice(page * rowsPerPage, (page + 1) * rowsPerPage);

    return (
      <div className="container">
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                {headings.map((heading, index) => (
                  <th key={index}>{heading}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {renderRows.map((row, rowIndex) => (
                <tr key={rowIndex}>
                  {row.map((data, dataIndex) => (
                    <td key={dataIndex}>{data}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="pagination-container">
          <span className="info">Page {page + 1}, Out of {totalPages}</span>
          <Pagination
            count={totalPages}
            page={page}
            onChange={this.handleChangePage}
            shape="rounded"
            className="pagination"
          />
        </div>
      </div>
    );
  }
}

export default Table;