import { Grid, AppBar } from '@mui/material';
import React from 'react';
import PropTypes from 'prop-types';
import CustomTypography from './Typography';
import customIcons from '../utils/Icons/index';
import './ComponentStyles.css';

/**
 *
 * @param {*} props
 * @returns
 */
function CustomAppBar(props) {
  const { logout } = props;

  return (
    <AppBar position="sticky" color="inherit">
      <Grid container className="styledToolbar" lg={12} sm={12} md={12} xs={12}>
        <Grid item className="UserBox">
          <CustomTypography text="Admin" />
          <img
            width="20px"
            alt="user-icon"
            height="20px"
            src={customIcons.AdminLogout}
            aria-hidden
            onClick={logout}
            className="adminIcon"
          />
        </Grid>
      </Grid>
    </AppBar>
  );
}

export default CustomAppBar;

CustomAppBar.propTypes = {
  logout: PropTypes.func,
};
CustomAppBar.defaultProps = {
  logout: () => {},
};
