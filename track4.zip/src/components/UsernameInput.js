
import React from 'react';
import TextField from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';

const UsernameInput = () => {
  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      <span style={{ marginRight: '8px' }}>Username</span>
      <TextField
        placeholder="Enter username"
        style={{ outlineColor: 'black' }} // Set outline color to black
        InputProps={{
          startAdornment: (
            <InputAdornment position="start" style={{ borderRadius: '5px' }}>
              <AccountCircleIcon />
            </InputAdornment>
          ),
        }}
      />
    </div>
  );
};

export default UsernameInput;
