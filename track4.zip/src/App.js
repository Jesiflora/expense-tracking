
import React from 'react';
import { BrowserRouter, Route, Routes } from "react-router-dom";
import SideNav from './Layout/SideMenu/Menu';




const App = () => {
  return (
    <div>

      <BrowserRouter>
      <Routes>
      {/* <Route path='/' element={<TwoSideGrid/>}/>
      <Route path='/Signup' element={<Signup/>}/> */}
     
      <Route path="/expense_tracking" element={<SideNav />} />
      {/* <Route path="/masters" element={<Masters />} />
      <Route path="/expenseSheet" element={<ExpenseSheet />} /> */}
      </Routes>
      </BrowserRouter>

 
    </div>
  );
};

export default App;